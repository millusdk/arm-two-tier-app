configuration SetupSqlServer 
{ 
   param 
   ( 
        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,

        [Int]$RetryCount=20,
        [Int]$RetryIntervalSec=30
    ) 
    
    Import-DscResource -ModuleName xStorage, xSQLServer, PSDesiredStateConfiguration

    Node localhost
    {
		LocalConfigurationManager
        {
            DebugMode = "ForceModuleImport"
            RebootNodeIfNeeded = $true
        }
		
		xWaitforDisk Disk2
        {
            DiskNumber = 2
            RetryIntervalSec =$RetryIntervalSec
            RetryCount = $RetryCount
        }
		
		xWaitforDisk Disk3
        {
            DiskNumber = 3
            RetryIntervalSec =$RetryIntervalSec
            RetryCount = $RetryCount
        }

        xDisk DataVolume
        {
            DiskNumber = 2
            DriveLetter = 'S'
			AllocationUnitSize = 64KB
        }

        xDisk LogVolume
        {
			DependsOn = "[xDisk]DataVolume"
            DiskNumber = 3
            DriveLetter = 'L'
        }
	}
	
	Node localhost
	{
        xSQLServerLogin Az-Admin
        {
            SQLServer = "."
            SQLInstanceName = "MSSQLSERVER"
            Name = "ad\az-admin"
            Ensure = "Present"
        }
		
		xSQLServerRole Add_ServerRoleToLogin
        {
            DependsOn = "[xSQLServerLogin]Az-Admin"
            Ensure = "Present"
            Name = "ad\az-admin"
            ServerRole = "sysadmin"
            SQLServer = "."
            SQLInstanceName = "MSSQLSERVER"
        }
		
		Registry SqlServerDataLocation
		{
			Ensure = "Present"
			Key = "HKEY_LOCAL_MACHINE\Software\Microsoft\MSSQLServer\MSSQLServer"
			ValueName = "DefaultData"
			ValueData = "S:\MSSQL\Data"
		}
		
		Registry SqlServerLogLocation
		{
			Ensure = "Present"
			Key = "HKEY_LOCAL_MACHINE\Software\Microsoft\MSSQLServer\MSSQLServer"
			ValueName = "DefaultLog"
			ValueData = "L:\MSSQL\Logs"
		}
	}
}